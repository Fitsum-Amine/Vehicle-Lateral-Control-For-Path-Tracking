ref_path = out.ref_path;
x_actual = out.X_actual;
y_actual = out.Y_actual;

figure; hold on; grid on; axis equal;

plot(ref_path(:,1), ref_path(:,2), 'b--', 'LineWidth', 2);
plot(x_actual, y_actual, 'r-', 'LineWidth', 2);

legend('Reference Path', 'Vehicle Path');
xlabel('X [m]'); ylabel('Y [m]');
title('Vehicle Path Tracking');


num_points = length(x_actual);
lateral_errors = zeros(num_points, 1);

for i = 1:num_points
    % Current vehicle position
    x_v = x_actual(i);
    y_v = y_actual(i);

    % Compute distances to all waypoints
    dx = ref_path(:,1) - x_v;
    dy = ref_path(:,2) - y_v;
    distances = sqrt(dx.^2 + dy.^2);

    % Find the minimum distance (lateral error)
    lateral_errors(i) = min(distances);
end

% Compute RMSE
rmse = sqrt(mean(lateral_errors.^2));

L_d = out.L_d; 
k = out.k;
v = out.v;
dt = out.dt;

% Values to display
rmse_str = sprintf('rmse: %.2f m', rmse);
ld_str = sprintf('L_d: %.2f m', L_d);
k_str = sprintf('k: %.2f', k);
v_str = sprintf('v: %.2f', v);
dt_str = sprintf('dt: %.2f', dt)

% Display as text in plot
text(0.05, 0.95, {dt_str, k_str, ld_str, v_str, rmse_str}, ...
    'Units', 'normalized', 'FontSize', 10, ...
    'VerticalAlignment', 'top', 'BackgroundColor', 'white');

% Display result
fprintf('Lateral rmse: %.2f m\n', rmse);
fprintf('Velocity: %.2f m/s\n', v);
fprintf('Lookahead distance: %.2f m\n', L_d);
fprintf('K: %.2f \n', k);
fprintf('dt: %.2f s\n', dt);

